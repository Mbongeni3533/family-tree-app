'use client'

import SpousePicker from '@/components/SpousePicker'
import { useState } from 'react'
import type { FamilyMember } from '@/types/family'

interface AddPersonFormProps {
  members: FamilyMember[]
  onAdd: (member: Omit<FamilyMember, 'id'>) => void
  onCancel: () => void
}

export default function AddPersonForm({ members, onAdd, onCancel }: AddPersonFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    birthYear: new Date().getFullYear(),
    gender: 'other' as const,
    notes: '',
    parentId: '',
    parent2Id: '',
    spouseIds: [] as string[],
  })

  const [previewUrl, setPreviewUrl] = useState<string | null>(null)

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const url = URL.createObjectURL(file)
      setPreviewUrl(url)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name.trim()) return

    const newMember = {
      name: formData.name,
      birthYear: formData.birthYear,
      gender: formData.gender,
      notes: formData.notes,
      parentId: formData.parentId || undefined,
      parent2Id: formData.parentId ? formData.parent2Id || undefined : undefined,
      spouseIds: formData.spouseIds.length ? formData.spouseIds : undefined,
      spouseId: formData.spouseIds[0],
      photoUrl: previewUrl || undefined,
    }

    onAdd(newMember)

    if (previewUrl && previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(previewUrl)
    }

    setFormData({
      name: '',
      birthYear: new Date().getFullYear(),
      gender: 'other',
      notes: '',
      parentId: '',
      parent2Id: '',
      spouseIds: [],
    })
    setPreviewUrl(null)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-[#e6dfc8] mb-1">
          Name *
        </label>
        <input
          type="text"
          required
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          className="w-full px-3 py-2 border border-[#2a2418] rounded-md text-[#f5f0e1]"
          placeholder="Enter name"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-[#e6dfc8] mb-1">
            Birth Year
          </label>
          <input
            type="number"
            value={formData.birthYear}
            onChange={(e) => setFormData({ ...formData, birthYear: parseInt(e.target.value) })}
            className="w-full px-3 py-2 border border-[#2a2418] rounded-md text-[#f5f0e1]"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-[#e6dfc8] mb-1">
            Gender
          </label>
          <select
            value={formData.gender}
            onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
            className="w-full px-3 py-2 border border-[#2a2418] rounded-md text-[#f5f0e1]"
          >
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-[#e6dfc8] mb-1">
          Photo
        </label>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-[#2a2418] flex items-center justify-center overflow-hidden">
            {previewUrl ? (
              <img src={previewUrl} alt="Preview" className="w-full h-full object-cover" />
            ) : (
              <span className="text-xs text-[#9a917c]">No Photo</span>
            )}
          </div>
          <input
            type="file"
            accept="image/*"
            onChange={handlePhotoChange}
            className="text-sm text-[#9a917c] file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-[#2a2310] file:text-[#d4af37]"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-[#e6dfc8] mb-1">
          Parent 1
        </label>
        <select
          value={formData.parentId}
          onChange={(e) => setFormData({ ...formData, parentId: e.target.value })}
          className="w-full px-3 py-2 border border-[#2a2418] rounded-md text-[#f5f0e1]"
        >
          <option value="">No parent</option>
          {members.map(p => (
            <option key={p.id} value={p.id}>{p.name}</option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-[#e6dfc8] mb-1">Parent 2 (optional)</label>
        <select
          value={formData.parent2Id}
          onChange={(e) => setFormData({ ...formData, parent2Id: e.target.value })}
          className="w-full px-3 py-2 border border-[#2a2418] rounded-md text-[#f5f0e1]"
        >
          <option value="">No second parent</option>
          {members.filter(p => p.id !== formData.parentId).map(p => (
            <option key={p.id} value={p.id}>{p.name}</option>
          ))}
        </select>
      </div>

      <SpousePicker options={members} value={formData.spouseIds} onChange={v => setFormData({ ...formData, spouseIds: v })} />

      <div>
        <label className="block text-sm font-medium text-[#e6dfc8] mb-1">
          Notes
        </label>
        <textarea
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          className="w-full px-3 py-2 border border-[#2a2418] rounded-md text-[#f5f0e1]"
          placeholder="Add any notes"
          rows={2}
        />
      </div>

      <div className="flex gap-2 pt-4">
        <button
          type="submit"
          className="flex-1 bg-[#d4af37] !text-[#0b0b0c] hover:bg-[#f0cf65] text-white font-semibold py-2 px-4 rounded-lg transition"
        >
          Add Person
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 bg-[#2a2418] hover:bg-[#3a3220] text-[#f5f0e1] font-semibold py-2 px-4 rounded-lg transition"
        >
          Cancel
        </button>
      </div>
    </form>
  )
}